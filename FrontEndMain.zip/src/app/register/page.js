import StepForm from '@/components/auth/registration/StepForm'
import React from 'react'

export default function page() {
  return (
    <div>
      <StepForm/>
    </div>
  )
}
