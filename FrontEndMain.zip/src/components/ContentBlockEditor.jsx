import React from 'react'

export default function ContentBlockEditor() {
  return (
    <div>
      
    </div>
  )
}
